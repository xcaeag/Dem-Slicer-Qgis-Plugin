<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="fr" sourcelanguage="en">
<context>
    <name>DemSlicer</name>
    <message>
        <source>DEM layer</source>
        <translation>Couche MNT</translation>
    </message>
    <message>
        <source>Build</source>
        <translation>Générer</translation>
    </message>

    <message>
        <source>Start</source>
        <translation>Démarrer</translation>
    </message>

    <message>
        <source>Line count</source>
        <translation>Nombre de profils</translation>
    </message>

    <message>
        <source>Z exageration</source>
        <translation>Accentuer le relief</translation>
    </message>

    <message>
        <source>X Step</source>
        <translation>Ecart entre deux mesures d'altitude</translation>
    </message>

    <message>
        <source>Z shift</source>
        <translation>Décalage des profils (en hauteur)</translation>
    </message>

    <message>
        <source>render lines</source>
        <translation>produire les lignes</translation>
    </message>

    <message>
        <source>render polygons</source>
        <translation>produire les polygones</translation>
    </message>

    <message>
        <source>render ridges</source>
        <translation>produire les lignes de crête</translation>
    </message>

    <message>
        <source>Orthogonal view</source>
        <translation>Vue orthogonale</translation>
    </message>

    <message>
        <source>Ornamentation layer</source>
        <translation>couche d'habillage</translation>
    </message>

    <message>
        <source>Save parameters</source>
        <translation>Sauver les paramètres</translation>
    </message>

    <message>
        <source>L</source>
        <translation>C</translation>
    </message>

    <message>
        <source>Load parameters</source>
        <translation>Charger les paramètres</translation>
    </message>

    <message>
        <source>Reset zone</source>
        <translation>Réinitialiser la vue</translation>
    </message>

    </context>
</TS>
